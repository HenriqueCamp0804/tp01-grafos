import funcoes
funcoes.menu()